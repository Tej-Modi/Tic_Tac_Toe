import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {
  isSubmitted = false;
  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  registerForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('',[
      Validators.required
    ])
});

  get email(){
    return this.registerForm.get('email');
  
  }

  get password(){
    return this.registerForm.get('password');
  }

  onSubmit() {
    this.isSubmitted = true;
    
      if(this.registerForm.value['email'] == "tej@gmail.com" && this.registerForm.value['password'] == "12345") {
        
      }

    console.log("demo",this.registerForm);
    
    if(this.registerForm.valid) {
      var namesArr = [];
    let data = this.registerForm.value;
        namesArr.push(data);
        localStorage.setItem('data', JSON.stringify(namesArr));
  
        console.table(namesArr);
        this.isSubmitted = false;
        this.registerForm.reset();
        this.router.navigate(['tictac']);
    }
    
      
      
    }

}