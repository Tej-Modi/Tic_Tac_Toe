import { TictacComponent } from './tictac/tictac.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


const routes: Routes = [
  { path: '', component: LoginComponentComponent},
  { path: 'tictac', component: TictacComponent}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
