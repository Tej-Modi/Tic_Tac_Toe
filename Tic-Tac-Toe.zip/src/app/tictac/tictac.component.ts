import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tictac',
  templateUrl: './tictac.component.html',
  styleUrls: ['./tictac.component.css']
})
export class TictacComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {
    
  }

  winMsg:string = "";
  isCross = false;
  itemArray:string[] = new Array(16).fill("");

  handleClick(itemNumber:number){
    if(this.itemArray[itemNumber] === '' ){
      this.itemArray[itemNumber] = this.isCross ? 'O' : 'X';
      this.isCross = !this.isCross

    }
    this.checkWinner();
  } 

  reloadGame = () => {
    this.winMsg = "";
    this.isCross = false;
    this.itemArray = new Array(16).fill("");
  }
  
  checkWinner = () => {
    if (
      this.itemArray[0] === this.itemArray[1] &&
      this.itemArray[0] === this.itemArray[2] &&
      this.itemArray[0] === this.itemArray[3] &&
       
      this.itemArray[0] !== ''
    ) {
      this.winMsg = `${this.itemArray[0]} won`;
    } 
    else if (
      this.itemArray[4] !== '' &&
      this.itemArray[4] === this.itemArray[5] &&
      this.itemArray[5] === this.itemArray[6] &&
      this.itemArray[6] === this.itemArray[7]
     
    ) {
      this.winMsg = `${this.itemArray[4]} won`;
    }
    else if (
      this.itemArray[8] !== '' &&
      this.itemArray[8] === this.itemArray[9] &&
      this.itemArray[9] === this.itemArray[10] &&
      this.itemArray[10] === this.itemArray[11]
    ) {
      this.winMsg = `${this.itemArray[8]} won`;
    }
    else if (
      this.itemArray[12] !== '' &&
      this.itemArray[12] === this.itemArray[13] &&
      this.itemArray[13] === this.itemArray[14] &&
      this.itemArray[14] === this.itemArray[15]
    ) {
      this.winMsg = `${this.itemArray[12]} won`;
    }
    
    else if (
      this.itemArray[0] !== '' &&
      this.itemArray[0] === this.itemArray[4] &&
      this.itemArray[4] === this.itemArray[8] &&
      this.itemArray[8] === this.itemArray[12]
      
    ) {
      this.winMsg = `${this.itemArray[0]} won`;
    }
    else if (
      this.itemArray[1] !== '' &&
      this.itemArray[1] === this.itemArray[5] &&
      this.itemArray[5] === this.itemArray[9] &&
      this.itemArray[9] === this.itemArray[13]
    ) {
      this.winMsg = `${this.itemArray[1]} won`;
    }
    else if (
      this.itemArray[2] !== '' &&
      this.itemArray[2] === this.itemArray[6] &&
      this.itemArray[6] === this.itemArray[10] &&
      this.itemArray[10] === this.itemArray[14]
    ) {
      this.winMsg = `${this.itemArray[2]} won`;
    }
    else if (
      this.itemArray[3] !== '' &&
      this.itemArray[3] === this.itemArray[7] &&
      this.itemArray[7] === this.itemArray[11] &&
      this.itemArray[11] === this.itemArray[15]
    ) {
      this.winMsg = `${this.itemArray[3]} won`;
    }
    
    else if (
      this.itemArray[0] !== '' &&
      this.itemArray[0] === this.itemArray[5] &&
      this.itemArray[5] === this.itemArray[10] && 
      this.itemArray[10] === this.itemArray[15]
    ) {
      this.winMsg = `${this.itemArray[0]} won`;
    }
    else if (
      this.itemArray[3] !== '' &&
      this.itemArray[3] === this.itemArray[6] &&
      this.itemArray[6] === this.itemArray[9] && 
      this.itemArray[9] === this.itemArray[12]
    ) {
      this.winMsg = `${this.itemArray[3]} won`;
    }


  }
  
}
